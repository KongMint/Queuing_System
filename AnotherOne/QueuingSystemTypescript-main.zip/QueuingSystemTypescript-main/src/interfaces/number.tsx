export default interface INumber{
    no: string,
    customerName: string,
    serviceName: string,
    serviceCode: string,
    orderTime: string,
    expireTime: string,
    status: string,
    source: string,
}