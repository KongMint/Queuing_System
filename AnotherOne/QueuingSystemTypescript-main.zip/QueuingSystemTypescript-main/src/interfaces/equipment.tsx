export default interface IEquipment{
    name: string,
    code: string,
    service: string,
    connectStatus: boolean, 
    account: string, 
    password: string,
    type: string, 
    actionStatus: boolean,
    ipAddress: string,
}