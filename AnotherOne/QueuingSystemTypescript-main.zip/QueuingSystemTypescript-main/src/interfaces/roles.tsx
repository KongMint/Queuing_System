export default interface IRole{
    code: string,
    name: string,
    numberOfUser: number,
    description: string,
}