export default interface IServices{
    code: string, 
    name: string,
    from: string,
    to: string,
    surfix: string,
    prefix: string,
    actionStatus: boolean,
    reset: boolean,
    description: string,
}