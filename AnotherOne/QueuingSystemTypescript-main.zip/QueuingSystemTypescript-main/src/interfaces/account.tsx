export default interface IAccount{
    username: string,
    password: string,
    name: string,
    phone: string,
    email: string,
    role: string,
    status: string,
}